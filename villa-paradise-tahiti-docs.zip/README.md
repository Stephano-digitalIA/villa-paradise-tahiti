# Villa Paradise Tahiti — Projet de Refonte 2026

> **Client :** Villa Paradise Tahiti (villaparadisetahiti.com)
> **Agence :** TahitiTechDigital (TTD)
> **Date de démarrage :** Mars 2026
> **Chef de projet :** Stephano Belleme-Atuahiva

---

## Contexte rapide

Refonte complète d'un site de location saisonnière de villa à Tahiti, actuellement sur Wix (design daté). Cible : clientèle américaine haut de gamme. Objectif principal : augmenter les réservations directes et réduire la dépendance à Airbnb.

---

## Documentation du projet

| Fichier | Thème | Description |
|---|---|---|
| [01-vision-projet.md](docs/01-vision-projet.md) | Vision & Objectifs | Contexte business, pain points, KPIs, ROI |
| [02-design-identite.md](docs/02-design-identite.md) | Design & Branding | Palette, typographie, moodboard, directives visuelles |
| [03-cible-marche-us.md](docs/03-cible-marche-us.md) | Cible US | Personas, comportements d'achat, trust signals |
| [04-fonctionnalites.md](docs/04-fonctionnalites.md) | Fonctionnalités | Calculateur, panier, calendrier, features complètes |
| [05-contenu-pages.md](docs/05-contenu-pages.md) | Contenu & Pages | Arborescence du site, copy direction par page |
| [06-technique-stack.md](docs/06-technique-stack.md) | Stack Technique | Framework, hébergement, paiement, CMS, SEO |
| [07-expansion.md](docs/07-expansion.md) | Expansion | Phases futures, marketplace, fidélité, SEO international |

---

## Workflow du projet (5 étapes)

```
Étape 1 ✅  Documentation Markdown       ← Vous êtes ici
Étape 2     Zip + contexte Claude Code
Étape 3     Recommandation frameworks
Étape 4     5 pages template (1 par framework)
Étape 5     Choix du framework + développement
```

---

## Commandes utiles

```bash
# Compresser la documentation pour Claude Code
./zip-docs.sh

# Le zip sera généré ici :
# villa-paradise-tahiti-docs.zip
```

---

## Stack envisagée (à confirmer à l'Étape 3)

- **Framework :** Next.js 14+ ou Astro
- **Hébergement :** Vercel ou Netlify
- **Paiement :** Stripe + PayPal
- **CMS :** Sanity.io
- **Calendrier :** iCal sync (Airbnb + VRBO)

---

*TahitiTechDigital — Ia ora na* 🤙
